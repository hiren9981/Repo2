<?php
$conn=mysqli_connect("localhost","root","","portfolio");
if(isset($_POST['signup'])){
    $username= $_POST['username'];
    $name=$_POST['name'];
    $password=$_POST['password'];

if(empty($username) OR empty($name) OR empty($password)){
    header("Location:login.php?message=empty+fields");
    exit();
}
    //checking if username exists
    $sql="SELECT * FROM `login` WHERE username='$username'";
    $result= mysqli_query($conn,$sql);
    if(mysqli_num_rows($result)>0){
        header("Location:login.php?message=username+exists");
        exit();
    }else{
        $sql2="INSERT INTO `login`(`username`, `name`, `password`) VALUES ('$username','$name','$password');";
        if(mysqli_query($conn,$sql2)){
            header("Location:login.php?message=registration+success");
        }else{
            header("Location:login.php?message=registration+failed");
        }
    }
}else{
    header("Location:login.php");
}