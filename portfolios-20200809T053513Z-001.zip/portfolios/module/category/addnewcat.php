<?php
$conn=mysqli_connect("localhost","root","","portfolio");
if(!isset($_POST['submit'])){
	header("Location: show.php?message=Please+Add+a+Category");
	exit();
}else{
			$category_name = $_POST['category_name'];
			$sql = "INSERT INTO category (`category_name`) VALUES ('$category_name');";
			if(mysqli_query($conn, $sql)){
				header("Location: show.php?message=Added");
				exit();
			}else{
				header("Location: show.php?message=Error");
				exit();
			}
			
		}
?>