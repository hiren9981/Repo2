<!DOCTYPE html>
<html lang="en">
<head>
    <title>INSERT A RECORD</title>
</head>
<body>
<h1>Category</h1>
				<h1>ALL CATEGORIES:</h1>

        ADD NEW:
				<div id="addCatForm">
					<form action="addnewcat.php" method="post">
						<input type="text" name="category_name" class="form-control" placeholder="Category Name"><br>
						<button name="submit" class="btn btn-success">Add Category</button>
					</form><br>
				</div>
    <?php      
           $conn=mysqli_connect("localhost","root","","portfolio");
            $sql="SELECT * FROM `category`";
            $result= mysqli_query($conn,$sql);
            ?>
           
    <table border=1>
    <tr>
    <th>category_id</th>
    <th>category_name</th>
    <th>Delete</th>
    <th>Edit</th>
    </tr>
       <?php
       while($row = mysqli_fetch_assoc($result))
       {
           echo "<tr>";
           echo"<td>".$row['category_id']."</td>";
           echo"<td>".$row['category_name']."</td>";
            echo"<td><a href='delete.php?id=".$row['category_id']."' onClick='return confirm(".'"Are you sure to delete?"'.");'>DELETE</a></td>";
           echo"<td><a href='edit.php?id=".$row['category_id']."'>Edit</a></td>";
           echo"</tr>";
       }
// all this above while loop row is the name of the table of database
       ?>
    </table>
</body>
</html>