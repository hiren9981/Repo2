<?php
 $conn=mysqli_connect("localhost","root","","portfolio");
    if(isset($_GET['id'])){
        $id=$_GET['id'];
        $sql ="SELECT * FROM `category` WHERE 1";
        $result=mysqli_query($conn,$sql);
        while($row=mysqli_fetch_assoc($result)){
            ?>
            <form method="post"> 
                     category id: <input type="text" name="category_id" value="<?php echo $row['category_id'];?>"required><br>
                    category name: <input type="text" name="name" value="<?php echo $row['category_name'];?>"required><br>
                    <input type="submit" name="submit">
                </form>
            <?php      
             if(isset ($_POST['submit'])){
                 $category_id= $_POST['category_id'];
                 $category_name=$_POST['name'];
                 

                 $sql2="UPDATE `category` SET `category_name` = '$category_name' WHERE `category`.`category_id` = '$id'";
                 
                //  UPDATE `category` SET `category_id`='$category_id',`category_name`='$category_name' WHERE category_id='$id'
                 if(mysqli_query($conn,$sql2)){
                    header("Location:show.php?Updatedsuccessfully");
                 }

                }
            }
    }else{
        header("Location: show.php");

    }

?>