<?php
$conn=mysqli_connect("localhost","root","","portfolio");
if(isset($_GET['id'])){
$id=$_GET['id'];

$sql="DELETE FROM `category` WHERE category_id='$id'";

if(mysqli_query($conn,$sql)){
    header("Location:addnewcat.php?DeletedSuccessfully");
}

}else{
    header("Location:addnewcat.php");
}


?>