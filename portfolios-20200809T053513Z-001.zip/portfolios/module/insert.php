<?php

$conn=mysqli_connect("localhost","root","","portfolio");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>ADD NEW PROJECT</title>
    <link rel="stylesheet" href="../style/bootstrap.min.css">
		<link rel="stylesheet" href="../style.css">
</head>
<body>
<H1>

 ADD NEW PROJECT</H1>
 
    <form method="post" enctype="multipart/form-data"> 
        PROJECT NAME: <input type="text" name="name" required><br>
        TECHNOLOGY USED: <input type="text" name="tech" required> <br>
        PROJECT LINK: <input type="text" name="link" required> <br> 
        CATEGORY: 
        <select name="category"  type="text">
        <?php 
        $sql="SELECT * FROM `category`";
        $result=mysqli_query($conn,$sql);
        while($row = mysqli_fetch_assoc($result)){
            $category_id = $row['category_id'];
            $category_name = $row['category_name'];
            echo $category_id;
            ?>
            <option value="<?php echo $category_id;?>"><?php echo $category_name;?></option>
            <?php
        }
        ?>
        </select><br>
        
         <br>
        image:<input type="file" name="file" id="exampleFormControlFile1"><br>
        
        DESCRIPTION: <input type="text" name="description" required> <br>
        <input type="submit" name="submit">
    </form>
    <?php      
        if(isset ($_POST['submit'])){
            $project_name= $_POST['name'];
            $technologies_used=$_POST['tech'];
            $project_link=$_POST['link'];
            $category=$_POST['category'];
            $description=$_POST['description'];

            $file = $_FILES['file'];
                
                 $fileName = $file['name'];
                 $fileType = $file['type'];
                 $fileTmp = $file['tmp_name'];
                 $fileErr = $file['error'];
                 $fileSize = $file['size'];
           
                 $destination = "img/".$fileName;
           
                 move_uploaded_file($fileTmp,$destination);
            
    
// the above left side wala part is for the values of the sql query
// the above right side wala part is the names  of the form above written

            $conn=mysqli_connect("localhost","root","","portfolio");
      
            $sql="INSERT INTO `project`(`project_id`, `project_name`, `technologies_used`, `project_link`, `category_id`, `description`, `post_images`) 
            VALUES (null,'$project_name','$technologies_used','$project_link','$category','$description','$destination');";
 
            if(mysqli_query($conn,$sql)){
                echo " <h1>RECORD ADDED SUCCESFULLY</h1> ";
            
        }
     
    }
    ?>
</body>
</html>