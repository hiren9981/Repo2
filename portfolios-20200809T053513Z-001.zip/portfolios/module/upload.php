<!doctype html>
<html>
<head>
<title>uploading php</title>
</head>
<body>
    <form method="post" enctype="multipart/form-data">
    <input type="file" name="file"><input type="submit" name="submit" value="upload">
    </form>
    <?php 
    if(isset($_POST['submit'])){
     $file=$_FILES['file'];
     
      $fileName = $file['name'];
      $fileType = $file['type'];
      $fileTmp = $file['tmp_name'];
      $fileErr = $file['error'];
      $fileSize = $file['size'];

      $destination = "img/".$fileName;

      move_uploaded_file($fileTmp,$destination);
      


    }?>

</body>
</html>