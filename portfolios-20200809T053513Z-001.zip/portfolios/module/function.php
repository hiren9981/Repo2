<?php
include_once "conn/connection.php";
 
            function getCategoryName($id){
                global $conn;
                $sql="SELECT * FROM `category` WHERE category_id='$id'";
                $result=mysqli_query($conn,$sql);
                while($row=mysqli_fetch_assoc($result)){
                    $name=$row['$category_name'];
                    echo $name;
                }
            }


?>