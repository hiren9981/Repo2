<?php
              $conn=mysqli_connect("localhost","root","","portfolio");

    if(isset($_GET['id'])){
        $id=$_GET['id'];
        $sql ="SELECT * FROM `project` WHERE project_id='$id'";
        $result=mysqli_query($conn,$sql);
        while($row=mysqli_fetch_assoc($result)){
            ?>
            <form method="post"> 
                     project id: <input type="text" name="project_id" value="<?php echo $row['project_id'];?>"required><br>
                    project name: <input type="text" name="name" value="<?php echo $row['project_name'];?>"required><br>
                    technologies used: <input type="text" name="technologies_used" value="<?php echo $row['technologies_used'];?>"required><br>
                    project link: <input type="text" name="project_link" value="<?php echo $row['project_link'];?>"required><br>
                    category: <input type="text" name="category_id" value="<?php echo $row['category_id'];?>"required><br>
                    description: <input type="text" name="description" value="<?php echo $row['description'];?>"required><br>
                    <input type="submit" name="submit">
                </form>
            <?php      
             if(isset ($_POST['submit'])){
                 $project_id= $_POST['project_id'];
                 $project_name= $_POST['name'];
                 $tech=$_POST['technologies_used'];
                 $project_link=$_POST['project_link'];
                 $category_id=$_POST['category_id'];
                 $description=$_POST['description'];

                 $sql2="UPDATE `project` SET `project_id`='$project_id',`project_name`='$project_name',`technologies_used`='$tech',`project_link`='$project_link',`category_id`='$category_id',`description`='$description' WHERE `project`.`project_id` = '$id'";
                 
                //  UPDATE `category` SET `category_id`='$category_id',`category_name`='$category_name' WHERE category_id='$id'
                 if(mysqli_query($conn,$sql2)){
                    header("Location:allprojects.php?Updatedsuccessfully");
                 }

                }
            }
    }else{
        header("Location: allprojects.php");

    }

?>