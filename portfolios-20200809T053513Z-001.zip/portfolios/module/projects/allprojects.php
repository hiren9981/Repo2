<!DOCTYPE html>
<html lang="en">
<head>
    <title>INSERT A RECORD</title>
</head>
<body>
<h1>PROJECTS</h1>
				<h1>ALL PROJECTS:</h1>
                ADD NEW:
				<button name="submit" class="btn btn-success"> <a href="../insert.php">Add New</a></button>
					
      
    <?php      
           $conn=mysqli_connect("localhost","root","","portfolio");

            $sql="SELECT * FROM `project`";
            $result= mysqli_query($conn,$sql);
            ?>
           
    <table border=1>
    <tr>
    <th>project_id</th>
    <th>project_name</th>
    <th>action</th>
    
    </tr>
       <?php
       while($row = mysqli_fetch_assoc($result))
       {
           echo "<tr>";
           echo"<td>".$row['project_id']."</td>";
           echo"<td>".$row['project_name']."</td>";
            echo"<td><a href='delete.php?id=".$row['project_id']."' onClick='return confirm(".'"Are you sure to delete?"'.");'>DELETE</a>
           <a href='edit.php?id=".$row['project_id']."'>Edit</a></td>";
           echo"</tr>";
       }
// all this above while loop row is the name of the table of database
       ?>
    </table>
</body>
</html>