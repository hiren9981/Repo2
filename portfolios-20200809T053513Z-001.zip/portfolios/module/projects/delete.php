<?php
           $conn=mysqli_connect("localhost","root","","portfolio");

if(isset($_GET['id'])){
$id=$_GET['id'];

$sql="DELETE FROM `project` WHERE project_id='$id'";

if(mysqli_query($conn,$sql)){
    header("Location:allprojects.php?DeletedSuccessfully");
}

}else{
    header("Location:allprojects.php");
}


?>