 <?php
$conn=mysqli_connect("localhost","root","","portfolio");

        if(!isset($_GET['id'])){
            header("Location:../index.php");
         }else{
            $id=$_GET['id'];
            if(is_numeric($id)){
                $sql = "SELECT * FROM category WHERE category_id='$id'";
                $result=mysqli_query($conn,$sql);}
                //check if categroy exists
                // if(mysqli_num_rows($result)<=0){
                //     // no category
                //     header("Location: index.php?noresult");
                // }else{

           ?> 
<!DOCTYPE html>
<html lang="en">
	<head>
		<title>My Dynamic Site</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="style/bootstrap.min.css">
		<link rel="stylesheet" href="style/style.css">
	</head>
	<body>

			
		 <div class="container">
			<?php
					$sql = "SELECT * FROM `category`";
					$result = mysqli_query($conn, $sql);
					while($row=mysqli_fetch_array($result)){
						$category_id = $row['category_id'];
						$category_name = $row['category_name'];
						
						?>
						 <a href="category.php?id=<?php echo $category_id ?>"><?php echo $category_name; ?></a>
						<?php
					}
				?>
				</div>
                <h4>showing all category </h4><?php echo $id;?>
		<?php 
			//pagination get
			if(isset($_GET['p'])){
				
				$sql = "SELECT * FROM `project` where category_id='$id'";
			}else{
				$sql = "SELECT * FROM `project` where category_id='$id'";
			}
		?>
		<div class="card-columns">
		<?php 
			
			$result = mysqli_query($conn, $sql);
			while($row=mysqli_fetch_assoc($result)){
				$project_name = $row['project_name']; 
				$project_id = $row['project_id'];
			
		?>
			<div class="card" style="width: 18rem;">
				
				<div class="card-body">
				<h5 class="card-title"><?php echo $project_name ?></h5>
				<a href="post.php?id=<?php echo $project_id; ?>" class="btn btn-primary">Read More</a>
				</div>
			</div>
			
			<?php }?>
		</div>
			<!-- <?php 
				echo "<center>";
				for($i=1;$i<=$totalpages;$i++){
					?>
					<a href="?p=<?php echo $i; ?>"><button class="btn btn-info"><?php echo $i; ?></button></a>&nbsp;
					<?php
				}
				echo "</center>";
			?> -->
		</div>
	<br><br>
	
	
	</body>
</body>
</html>
<!-- 



                        <?php
                    }
                  
  ?> -->