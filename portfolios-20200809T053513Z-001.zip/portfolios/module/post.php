<?php

$conn=mysqli_connect("localhost","root","","portfolio");

?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<title>post</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="../includes/css/bootstrap.min.css">
		<link rel="stylesheet" href="../includes/css/style.css">
	</head>
	<body>
    <?php
        if(!isset($_GET['id'])){
            header("Location:../index.php");
         }else{
            $id=$_GET['id'];
            $sql = "SELECT * FROM `project` where project_id='$id'";}?>
                 <?php 
                        $result = mysqli_query($conn, $sql);
                        while($row=mysqli_fetch_assoc($result)){
                            $project_name = $row['project_name']; 
                            $project_id = $row['project_id'];
                            $technologies_used = $row['technologies_used'];
                            $project_link=$row['project_link'];
                            $category_id = $row['category_id'];
                            $post_images=$row['post_images'];
                            $description = $row['description'];


                ?>
			 <div class="container">
                            <img src="<?php echo $post_images; ?>">
                            <h1><?php echo $project_name; ?></h1>
                            <hr>
                            <!-- <a href="<?php echo $project_link; ?>"> website</a> -->
                            <h4>Technologies Used: <?php echo $technologies_used ; ?></h4>
                            <h4>Project Link: <a href="<?php echo $project_link ; ?>"> Website</a></h4>
                            <p> <h4>description:</h4><?php echo $description; ?></p>
                            
                     </div>
			<?php }?>
                        
    </body>