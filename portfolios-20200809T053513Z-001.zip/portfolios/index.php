
<!DOCTYPE html>
<html lang="en">
	<head>
		<title>html page</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="includes/css/bootstrap.min.css">
		<link rel="stylesheet" href="includes/css/style.css">
	</head>
	<body>

	  <?php
$conn=mysqli_connect("localhost","root","","portfolio");
?>

			
		 <div class="container">
			<?php
					$sql = "SELECT * FROM `category`";
					$result = mysqli_query($conn, $sql);
					while($row=mysqli_fetch_array($result)){
						$category_id = $row['category_id'];
						$category_name = $row['category_name'];
						
						?>
						 <a href="module/category.php?id=<?php echo $category_id ?>"><?php echo $category_name; ?></a>
						<?php
					}
				?>
				</div>
		 
		<?php 
			//pagination get
			if(isset($_GET['p'])){
				
				$sql = "SELECT * FROM `project` ORDER BY project_id DESC ";
			}else{
				$sql = "SELECT * FROM `project` ORDER BY project_id DESC ";
			}
		?>
		<div class="card-columns">
		<?php 
			
			$result = mysqli_query($conn, $sql);
			while($row=mysqli_fetch_assoc($result)){
				$project_name = $row['project_name']; 
				$project_id = $row['project_id'];
				$post_images = $row['post_images'];

			
		?>
			<div class="card" style="width: 18rem;">
				<img class="card-img-top" src="<?php echo $post_images;?>" alt="Card image cap">
				<div class="card-body">
				<h5 class="card-title"><?php echo $project_name ?></h5>
				<a href="module/post.php?id=<?php echo $project_id; ?>" class="btn btn-primary">Read More</a>
				</div>
			</div>
			
			<?php }?>
		</div>
		
		</div>
	<br><br>
	
	
	</body>
</body>
</html>