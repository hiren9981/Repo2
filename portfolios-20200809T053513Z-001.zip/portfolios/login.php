<?php session_start();?>
<html>
    <head>
        <title>login Page</title>
    </head>     
    <body>
        <div>
           <center>
              <form action="login1.php" method="POST">
                    Username: <input type="text" name="username"><br>
                    Password: <input type="password" name="password"><br>
                    <input type="submit" name="Login" value="Login">
              </form></center>
            </div>
     <br>
            <div>
           <center>
              <form action="signup.php" method="POST">
                    Username: <input type="text" name="username"><br> 
                    name: <input type="text" name="name"><br>
                    Password: <input type="password" name="password"><br>
                    <input type="submit" name="signup" value="signup">
              </form></center>
            </div>
    </body>
</html>