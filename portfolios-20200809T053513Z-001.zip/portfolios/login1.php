<?php

$conn=mysqli_connect("localhost","root","","portfolio");
?>
<?php session_start();

if(isset($_POST['Login'])){
	$username=$_POST['username'];
	$password=$_POST['password'];

    $sql="SELECT * FROM `login` WHERE username='$username'";
    $result=mysqli_query($conn,$sql);
    if(mysqli_num_rows($result)<=0){
        header("Location:login.php?message=LoginError");
    }else{
        while($row=mysqli_fetch_assoc($result)){
            if($row['password']!=$password){
                header("Location:login.php?message=Login+error");
            }else if($row['password']=$password){
                
                $_SESSION['id']==$row['id'];
                $_SESSION['username']==$row['username'];
                $_SESSION['name']==$row['name'];
                $_SESSION['password']==$row['password'];
            header("Location:index.php?message=Login+success");     
            
            }
        }
        }
    }

else{
    header("Location :login.php");
}

?>
